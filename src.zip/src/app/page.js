'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { supabase } from '../lib/supabaseClient.js';
import AuthBadge from '../components/AuthBadge.js';
import ItemForm from '../components/ItemForm.js';
import ItemList from '../components/ItemList.js';
import AdminPanel from '../components/AdminPanel.js';
import * as XLSX from 'xlsx';

/* ================================
   ENV / ANTI-FREEZE
=================================== */
const hiddenReloadMs = Number(process.env.NEXT_PUBLIC_HIDDEN_RELOAD_MS || 20000);

/* ================================
   COMPONENTE PRINCIPAL
=================================== */
export default function Page(){
  // auth / perfil
  const [session, setSession] = useState(null);
  const [role, setRole] = useState('visitor');
  const [active, setActive] = useState(false);

  // dados / ui
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState(null);
  const [adminOpen, setAdminOpen] = useState(false);

  // controles internos
  const subsRef = useRef([]);
  const lastHiddenAt = useRef(null);

  const isLogged = !!session?.user;
  const canWrite = active && ['member','admin'].includes(role);
  const isAdmin  = active && role === 'admin';

  /* ---------- helpers ---------- */
  function clearSubs(){
    subsRef.current.forEach(ch => supabase.removeChannel(ch));
    subsRef.current = [];
  }

  async function refreshAuth(){
    const { data: { session: ses } } = await supabase.auth.getSession();
    setSession(ses || null);
    setRole('visitor'); setActive(false);

    if (ses?.user){
      const { data } = await supabase
        .from('profiles')
        .select('role,active')
        .eq('id', ses.user.id)
        .maybeSingle();
      if (data){ setRole(data.role || 'visitor'); setActive(!!data.active); }
    }
  }

  async function loadItems(){
    let q = supabase.from('items').select('*');
    if (search) q = q.ilike('name', `%${search}%`);
    const { data } = await q;
    setItems(data || []);
  }

  function initRealtime(){
    clearSubs();
    const itemsCh = supabase.channel('items-rt')
      .on('postgres_changes', { event:'*', schema:'public', table:'items' }, loadItems)
      .subscribe();

    const profilesCh = supabase.channel('profiles-rt')
      .on('postgres_changes', { event:'*', schema:'public', table:'profiles' },
        async () => { await refreshAuth(); if (adminOpen) await loadItems(); })
      .subscribe();

    subsRef.current = [itemsCh, profilesCh];
  }

  function setupResumers(){
    const onVisible = async () => {
      if (document.visibilityState === 'visible'){
        if (lastHiddenAt.current && Date.now() - lastHiddenAt.current > hiddenReloadMs){
          // ficou oculta muito tempo → recarrega duro
          location.reload();
          return;
        }
        await refreshAuth();
        await loadItems();
        initRealtime();
      } else {
        lastHiddenAt.current = Date.now();
      }
    };
    const onOnline = async () => { await refreshAuth(); await loadItems(); initRealtime(); };

    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('online', onOnline);

    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('online', onOnline);
    };
  }

  /* ---------- bootstrap com cleanup correto ---------- */
  useEffect(() => {
    let mounted = true;
    let off = () => {};
    let authSub;

    (async () => {
      await refreshAuth();
      if (!mounted) return;

      await loadItems();
      if (!mounted) return;

      initRealtime();
      off = setupResumers();

      authSub = supabase.auth.onAuthStateChange(async () => {
        await refreshAuth();
        await loadItems();
      });
    })();

    return () => {
      mounted = false;
      try { off && off(); } catch {}
      try { authSub?.data?.subscription?.unsubscribe?.(); } catch {}
      clearSubs();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- ações UI ---------- */
  async function onDelete(item){
    if (!canWrite) return alert('Sem permissão.');
    if (!confirm(`Excluir "${item.name}"?`)) return;
    const { error } = await supabase.from('items').delete().eq('id', item.id);
    if (error) alert(error.message);
  }

  async function exportXlsx(){
    const { data } = await supabase.from('items').select('*').order('name');
    if (!data?.length) return alert('Nenhum item para exportar.');
    const rows = data.map(x => ({
      Item: x.name, Quantidade: x.quantity, Local: x.location, Foto: x.photo_url || 'N/A'
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Inventário');
    XLSX.writeFile(wb, 'inventario_kids.xlsx');
  }

  const filtered = useMemo(
    () => items.filter(i => !search || i.name.toLowerCase().includes(search.toLowerCase())),
    [items, search]
  );

  /* ---------- render ---------- */
  return (
    <div className="container">
      <div className="header">
        <div className="brand">Inventário Kids</div>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          <AuthBadge
            email={session?.user?.email || null}
            role={role}
            active={active}
            onClick={async () => {
              if (!isLogged){
                await supabase.auth.signInWithOAuth({
                  provider: 'google',
                  options: { redirectTo: window.location.origin }
                });
              } else {
                alert(`${session.user.email} • ${active ? role.toUpperCase() : 'VISITANTE'}`);
              }
            }}
          />
          {isAdmin && (
            <button onClick={() => setAdminOpen(v => !v)} className="warn">
              {adminOpen ? 'Fechar Admin' : 'Abrir Admin'}
            </button>
          )}
          {isLogged && (
            <button onClick={async () => { await supabase.auth.signOut(); location.reload(); }}>
              Sair
            </button>
          )}
        </div>
      </div>

      <div className="grid" style={{marginTop:16}}>
        <ItemForm canWrite={canWrite} onSaved={loadItems} editing={editing} setEditing={setEditing} />
        <div className="card">
          <h3>Pesquisar / Exportar</h3>
          <input placeholder="Buscar por nome" value={search} onChange={e=>setSearch(e.target.value)} />
          <div className="actions" style={{marginTop:10}}>
            <button onClick={loadItems}>Atualizar</button>
            <button onClick={exportXlsx}>Exportar XLSX</button>
          </div>
          <div className="card" style={{marginTop:10, background:'#0b1220', opacity:.8}}>
            {!canWrite && <div>Você está como <b>visitante</b>. Faça login para cadastrar/editar.</div>}
            {canWrite && !isAdmin && <div>Você é <b>membro</b>. Pode cadastrar/editar itens.</div>}
            {isAdmin && <div>Você é <b>ADMIN</b>. Pode tudo, inclusive gerenciar usuários.</div>}
          </div>
        </div>
      </div>

      <div style={{marginTop:16}}>
        <ItemList items={filtered} canWrite={canWrite} onEdit={setEditing} onDelete={onDelete} />
      </div>

      <AdminPanel visible={adminOpen} onClose={() => setAdminOpen(false)} isAdmin={isAdmin} />

      <div className="footer">Supabase + Next.js • Realtime com retomada quando a aba volta ao foco/online.</div>
    </div>
  );
}
