'use client';
import { useMemo } from 'react';


export default function ItemList({ items, canWrite, onEdit, onDelete }){
const sorted = useMemo(()=>[...items].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at)),[items]);
return (
<div className="item-grid">
{sorted.length===0 && <div className="card">Nenhum item encontrado.</div>}
{sorted.map(item=> (
<div className="item-card" key={item.id}>
{item.photo_url && <img src={item.photo_url} alt={item.name}
onClick={()=>{
const v = document.createElement('div'); v.className='viewer';
v.innerHTML = `<img src="${item.photo_url}"><button class="close">✖</button>`;
v.addEventListener('click', ()=> v.remove());
document.body.appendChild(v);
}} />}
<h3>{item.name}</h3>
<div style={{opacity:.8}}>
<div><b>Qtd:</b> {item.quantity}</div>
<div><b>Local:</b> {item.location}</div>
</div>
{canWrite && (
<div className="actions">
<button onClick={()=>onEdit(item)}>✏️ Editar</button>
<button className="danger" onClick={()=>onDelete(item)}>🗑️ Excluir</button>
</div>
)}
</div>
))}
</div>
);
}