// src/components/Test.js
export default function Test() {
  return (
    <div style={{ color: 'lime', backgroundColor: 'black', padding: '20px', fontSize: '24px' }}>
      ✅ Componente de Teste Carregado com Sucesso!
    </div>
  );
}