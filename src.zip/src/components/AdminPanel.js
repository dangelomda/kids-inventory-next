'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';

export default function AdminPanel({ visible, onClose, isAdmin }) {
  const [rows, setRows] = useState([]);
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);

  async function load() {
    if (!isAdmin) return;
    setBusy(true);
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('email');
    
    setBusy(false);
    if (error) return alert(error.message);
    setRows(data || []);
  }

  useEffect(() => {
    if (visible) {
      load();
    }
  }, [visible]);

  async function upsert() {
    if (!isAdmin) return alert('Apenas admin.');
    if (!email.includes('@')) return alert('E-mail inválido');
    const { error } = await supabase
      .from('profiles')
      .upsert(
        [{ email: email.trim(), role: 'member', active: true }],
        { onConflict: 'email' }
      );
    if (error) return alert(error.message);
    setEmail('');
    load();
  }

  async function toggle(p) {
    const { error } = await supabase
      .from('profiles')
      .update({ active: !p.active })
      .eq('id', p.id);
    if (error) return alert(error.message);
    load();
  }

  async function promote(p) {
    const { error } = await supabase
      .from('profiles')
      .update({ role: 'admin' })
      .eq('id', p.id);
    if (error) return alert(error.message);
    load();
  }

  async function demote(p) {
    const { error } = await supabase
      .from('profiles')
      .update({ role: 'member' })
      .eq('id', p.id);
    if (error) return alert(error.message);
    load();
  }

  async function remove(p) {
    if (confirm(`Remover ${p.email}?`)) {
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', p.id);
      if (error) return alert(error.message);
      load();
    }
  }

  if (!visible) {
    return null;
  }

  return (
    <div className="card" style={{ marginTop: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3>Painel Admin</h3>
        <button onClick={onClose}>Fechar</button>
      </div>

      <div className="grid" style={{ marginTop: 10 }}>
        <div className="card">
          <h4>Adicionar usuário (pré-cadastro)</h4>
          <input
            placeholder="email@dominio"
            value={email}
            onChange={e => setEmail(e.target.value)}
          />
          <div className="actions">
            <button className="success" disabled={busy} onClick={upsert}>
              Adicionar/Ativar
            </button>
          </div>
        </div>

        <div className="card">
          <h4>Perfis</h4>
          <table className="table">
            <thead>
              <tr>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(p => (
                <tr key={p.id}>
                  <td>{p.email}</td>
                  <td>
                    <span className={`role-badge ${p.role}`}>{p.role}</span>
                  </td>
                  <td>{p.active ? 'ATIVO' : 'INATIVO'}</td>
                  <td style={{ display: 'flex', gap: 8 }}>
                    <button onClick={() => toggle(p)}>{p.active ? 'Desativar' : 'Ativar'}</button>
                    <button onClick={() => promote(p)}>Admin</button>
                    <button onClick={() => demote(p)}>Membro</button>
                    <button className="danger" onClick={() => remove(p)}>Remover</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}