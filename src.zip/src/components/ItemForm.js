'use client';
import { supabase } from '@/lib/supabaseClient';
import { useState } from 'react';


const BUCKET = 'item-photos';


async function compressImage(file, maxWidth=800, quality=0.7){
const img = document.createElement('img');
const url = URL.createObjectURL(file);
await new Promise((res, rej)=>{ img.onload=res; img.onerror=rej; img.src=url; });
const scale = Math.min(1, maxWidth/img.naturalWidth);
const w = Math.round(img.naturalWidth*scale); const h = Math.round(img.naturalHeight*scale);
const canvas = document.createElement('canvas'); canvas.width=w; canvas.height=h;
const ctx = canvas.getContext('2d'); ctx.drawImage(img,0,0,w,h);
const blob = await new Promise(r=> canvas.toBlob(r,'image/jpeg',quality));
URL.revokeObjectURL(url);
return new File([blob], file.name.replace(/\.[^.]+$/,'.jpg'), { type:'image/jpeg' });
}


function makeKey(){
const rnd = (crypto?.randomUUID?.() || Math.random().toString(36).slice(2));
return `${rnd}-${Date.now()}.jpg`;
}


export default function ItemForm({ canWrite, onSaved, editing, setEditing }){
const [name,setName]=useState(editing?.name||'');
const [quantity,setQuantity]=useState(editing?.quantity||0);
const [location,setLocation]=useState(editing?.location||'');
const [file,setFile]=useState(null);
const [busy,setBusy]=useState(false);


async function uploadPhoto(file){
const key = makeKey();
const { error } = await supabase.storage.from(BUCKET).upload(key, file);
if (error) throw error;
const { data } = supabase.storage.from(BUCKET).getPublicUrl(key);
return { photo_key:key, photo_url:`${data.publicUrl}?v=${Date.now()}` };
}


const handleSubmit = async (e)=>{
e.preventDefault();
if (!canWrite) return alert('Faça login para cadastrar.');
setBusy(true);
try{
const payload = { name:name.trim(), quantity:Number(quantity)||0, location:location.trim() };
if (file){
const compressed = await compressImage(file);
const refs = await uploadPhoto(compressed);
Object.assign(payload, refs);
}
if (editing){
await supabase.from('items').update(payload).eq('id', editing.id);
if (file && editing.photo_key){ await supabase.storage.from(BUCKET).remove([editing.photo_key]); }
} else {
await supabase.from('items').insert([payload]);
}
setName(''); setQuantity(0); setLocation(''); setFile(null); setEditing(null);
onSaved();
} catch(err){ alert(err.message||String(err)); }
finally{ setBusy(false); }
};


return (
<form className="card" onSubmit={handleSubmit}>
<h3>{editing? 'Editar item':'Cadastrar item'}</h3>
<input placeholder="Nome" value={name} onChange={e=>setName(e.target.value)} required />
<input type="number" placeholder="Quantidade" value={quantity} onChange={e=>setQuantity(e.target.value)} />
<input placeholder="Local" value={location} onChange={e=>setLocation(e.target.value)} />
<input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0]||null)} />
<div className="actions">
<button className="primary" disabled={busy}>{editing? 'Salvar alterações':'Cadastrar'}</button>
{editing && <button type="button" onClick={()=>setEditing(null)}>Cancelar</button>}
</div>
</form>
);
}